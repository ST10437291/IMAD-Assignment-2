package vcmsa.ci.myhistoryapp

import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ScoreActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score)

        val score = intent.getIntExtra("score", 0)
        val questions = intent.getStringArrayExtra("questions")!!
        val answers = intent.getBooleanArrayExtra("answers")!!

        val txtScore = findViewById<TextView>(R.id.txtScore)
        val txtFeedback = findViewById<TextView>(R.id.txtFinalFeedback)
        val txtReview = findViewById<TextView>(R.id.txtReview)
        val btnExit = findViewById<Button>(R.id.btnExit)

        txtScore.text = "Your Score: $score / 5"
        txtFeedback.text = if (score >= 3) "Great job!" else "Keep practising!"

        // Build review text
        val reviewText = StringBuilder()
        for (i in questions.indices) {
            reviewText.append("Q: ${questions[i]}\nA: ${if (answers[i]) "True" else "False"}\n\n")
        }
        txtReview.text = reviewText.toString()

        btnExit.setOnClickListener {
            finishAffinity()
        }

        Log.d("ScoreActivity", "Score: $score")
    }
}
//W3Schools. (2024). W3Schools Online Web Tutorials. [online] Available at: https://www.w3schools.com/ [Accessed 16 May 2025]