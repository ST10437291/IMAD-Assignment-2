package vcmsa.ci.myhistoryapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class QuestionActivity : AppCompatActivity() {
    private val questions = arrayOf(
        "Nelson Mandela was president in 1994",
        "The Berlin Wall fell in 1989",
        "World War II ended in 1935",
        "Julius Caesar was a Roman emperor",
        "The Great Depression began in 1929"
    )

    private val answers = arrayOf(true, true, false, false, true)

    private var currentQuestion = 0
    private var score = 0

    private lateinit var txtQuestion: TextView
    private lateinit var txtFeedback: TextView
    private lateinit var btnNext: Button
    private lateinit var btnTrue: Button
    private lateinit var btnFalse: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question)

        txtQuestion = findViewById(R.id.txtQuestion)
        txtFeedback = findViewById(R.id.txtFeedback)
        btnNext = findViewById(R.id.btnNext)
        btnTrue = findViewById(R.id.btnTrue)
        btnFalse = findViewById(R.id.btnFalse)

        showQuestion()

        btnTrue.setOnClickListener { checkAnswer(true) }
        btnFalse.setOnClickListener { checkAnswer(false) }

        btnNext.setOnClickListener {
            currentQuestion++

            if (currentQuestion < questions.size) {
                showQuestion()
                txtFeedback.text = ""
            } else {
                // Go to ScoreActivity screen
                val intent = Intent(this, ScoreActivity::class.java)
                intent.putExtra("score", score)
                intent.putExtra("questions", questions)
                intent.putExtra("answers", answers.toBooleanArray())
                startActivity(intent)
                finish()

            }
        }

    }

    private fun showQuestion() {
        txtQuestion.text = questions[currentQuestion]
    }

    private fun checkAnswer(userAnswer: Boolean) {
        val correct = answers[currentQuestion]
        if (userAnswer == correct) {
            txtFeedback.text = "Correct!"
            score++
            Log.d("QuestionActivity", "Answer correct")
        } else {
            txtFeedback.text = "Incorrect"
            Log.d("QuestionActivity", "Answer incorrect")

        }
    }
}

//W3Schools. (2024). W3Schools Online Web Tutorials. [online] Available at: https://www.w3schools.com/ [Accessed 16 May 2025]