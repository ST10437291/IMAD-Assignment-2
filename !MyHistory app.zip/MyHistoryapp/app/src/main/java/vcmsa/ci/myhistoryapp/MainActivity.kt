package vcmsa.ci.myhistoryapp



import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d("MainActivity", "App Started")

        val startButton = findViewById<Button>(R.id.btnStart)
        startButton.setOnClickListener {
            val imageView: ImageView = findViewById(R.id.myImageView)
            Log.d("MainActivity", "Start Button Clicked")
            val intent = Intent(this, QuestionActivity::class.java)
            startActivity(intent)
        }
    }
}


